#ifndef _KAZZO_TASK_H_
#define _KAZZO_TASK_H_
enum{
	KAZZO_TASK_FLASH_IDLE = 0
};
#endif
