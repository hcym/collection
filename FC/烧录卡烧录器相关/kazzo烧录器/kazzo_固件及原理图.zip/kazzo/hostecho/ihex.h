#ifndef _IHEX_H_
#define _IHEX_H_
struct record;
struct record *ihex_new(void);
void ihex_destory(struct record *t);
bool ihex_load(const char *hex, struct record *t);
void ihex_write(struct record *t, long filter, uint8_t *image);
#endif
