#ifndef _FILE_H_
#define _FILE_H_
bool buf_load(uint8_t *buf, const char *file, int size);
void* buf_load_full(const char *file, int *size);
bool buf_save(const void *buf, const char *file, int size);
#endif
