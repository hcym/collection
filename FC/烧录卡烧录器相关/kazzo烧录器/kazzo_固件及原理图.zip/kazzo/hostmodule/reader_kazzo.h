#ifndef _READER_KAZZO_H_
#define _READER_KAZZO_H_
const struct reader_driver DRIVER_KAZZO;
#endif
