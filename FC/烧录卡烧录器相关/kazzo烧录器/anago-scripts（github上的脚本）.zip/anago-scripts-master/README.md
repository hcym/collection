Scripts for the "anago" NES cartridge dumper utility.

Related links:

* http://nesdev.parodius.com/bbs/viewtopic.php?t=7912
* http://sourceforge.jp/projects/unagi/releases/49771
* [how to write mapper scripts](http://unagi.osdn.jp/cgi-bin/hiki/hiki.cgi?how+to+describe+mapper+scripts)

Scripts here are all prefixed with an underscore (_) to make them stand out
from those scripts that come with the tool.
