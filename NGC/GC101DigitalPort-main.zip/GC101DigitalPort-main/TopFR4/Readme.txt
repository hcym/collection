Thickness 2mm
ENIG or better
