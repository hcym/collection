# GC101DigitalPort


Misc parts needed

1 x 2mm Screw x 10mm

1 x 2mm nut

Flex Cable= 687630152002

**The flex cable is much cheaper on aliexpress ie.. https://www.aliexpress.com/item/4000848923853.html


Installation Video

https://www.youtube.com/watch?v=QE5A_DTQPTs

Original Sale Page

https://www.black-dog.tech/gamecube-dol-101-digital-port-upgrade-kit.html



