Thickness .6mm
