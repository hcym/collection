Thickness 0.13 mm
1oz copper