/* 
 * File:   fmanager.h
 * Author: igor
 *
 * Created on December 7, 2021, 4:21 PM
 */

#ifndef MENU_H
#define	MENU_H

u8 fmanager();

#endif	/* MENU_H */

