/* 
 * File:   main.h
 * Author: igor
 *
 * Created on April 28, 2020, 12:46 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#include "sys.h"
#include "disk.h"
#include "everdrive.h"
#include "fs.h"
#include "fmanager.h"
#include "cfg.h"
#include "std.h"
#include "flash.h"

#endif	/* MAIN_H */

